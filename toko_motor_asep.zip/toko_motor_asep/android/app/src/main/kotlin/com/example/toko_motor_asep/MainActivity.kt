package com.example.toko_motor_asep

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
